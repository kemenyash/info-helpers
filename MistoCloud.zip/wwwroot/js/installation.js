﻿document.getElementById("startInstallationButton").addEventListener("click", function (event) {
    event.preventDefault();

    const inputFields = ["database_host", "database_user", "database_port", "database_password", "login", "password"];
    const credentials = {};

    inputFields.forEach(function (field) {
        credentials[field] = document.getElementById(field).value;
    });

    const json = JSON.stringify(credentials);

    fetch("/install", {
        method: "POST",
        body: json,
        headers: {
            "Content-type": "application/json; charset=UTF-8"
        }
    })
        .then(function (response) {
            switch (response.status) {
                case 200:
                    UIkit.notification({ message: 'Дані успішно збережені' });
                    window.location.href = '/dashboard';
                    break;
                case 403:
                    UIkit.notification({ message: 'Доступ заборонено!', status: 'danger' });
                    break;
                case 451:
                    UIkit.notification({ message: 'Некоректно заповнені поля', status: 'warning' });
                    break;
                case 401:
                    UIkit.notification({ message: 'Не вдалось підключитись до бази, перевірте правильність даних', status: 'warning' });
                    break;
                default:
                    UIkit.notification({ message: 'Сталася помилка при виконанні запиту', status: 'danger' });
                    break;
            }
        })
        .catch(function (error) {
            console.error('Помилка:', error);
        });
});
