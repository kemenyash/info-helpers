﻿document.addEventListener("DOMContentLoaded", function () {
    const addonsLink = document.querySelector('a[href="#addons"]');
    const settingsLink = document.querySelector('a[href="#settings"]');
    const logoutLink = document.querySelector('a[href="#logout"]');

    const targetContentDiv = document.querySelector('.uk-flex.uk-flex-center');
    const targetModalDiv = document.querySelector('.uk-modal-dialog.uk-modal-body');

    function fetchAndInjectHtml(url, targetElement, replaceData) {
        fetch(url)
            .then(response => response.text())
            .then(html => {
                for (const key in replaceData) {
                    if (replaceData.hasOwnProperty(key)) {
                        html = html.replace(key, replaceData[key]);
                    }
                }
                targetElement.innerHTML = html;
                executeScripts(targetElement);
            })
            .catch(error => {
                console.error("Download error:", error);
            });
    }

    function executeScripts(element) {
        const scriptElements = element.getElementsByTagName('script');
        for (let i = 0; i < scriptElements.length; i++) {
            eval(scriptElements[i].innerHTML);
        }
    }

    function showAddons() {
        targetContentDiv.innerHTML = '';
        const replaceData = {
            "[TELEGRAM_TOKEN]": addonsModalData.token,
            "[CONNECT_URL]": addonsModalData.connect_url
        };
        fetchAndInjectHtml("/parts/dashboard/addons_modal.html", targetModalDiv, replaceData);
        fetchAndInjectHtml("/parts/dashboard/addons.html", targetContentDiv, {});
    }

    function showSettings() {
        targetContentDiv.innerHTML = '';
        const replaceData = {
            "[ADMIN_USERNAME]": adminSettings.username
        };
        fetchAndInjectHtml("/parts/dashboard/settings.html", targetContentDiv, replaceData);
    }

    showAddons();

    if (preSecurityMode === 'True') {
        showSettings();
        UIkit.notification({ message: 'В цілях безпеки змініть пароль на інший', status: 'danger' });
    }

    logoutLink.addEventListener("click", function (e) {
        e.preventDefault();
        fetch("/api/auth/logout", {
            method: "POST"
        })
            .then(response => {
                if (response.status === 200) {
                    window.location.href = '/dashboard';
                }
            })
            .catch(error => {
                console.error('Помилка:', error);
            });
    });

    settingsLink.addEventListener("click", function (e) {
        e.preventDefault();
        showSettings();
    });

    addonsLink.addEventListener("click", function (e) {
        e.preventDefault();
        showAddons();
    });
});
